import 'package:flutter/material.dart';

import 'screens/library_screen.dart';

void main() => runApp(const KlipMuzikApp());

class KlipMuzikApp extends StatelessWidget {
  const KlipMuzikApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Klipmüzik',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.deepPurple,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const LibraryScreen(),
    );
  }
}
