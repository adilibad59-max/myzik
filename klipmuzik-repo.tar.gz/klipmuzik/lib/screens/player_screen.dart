import 'dart:io';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:video_player/video_player.dart';

import '../models/song.dart';

/// Üç sayfa: 1) şarkı kapağı  2) klip kapağı  3) klip.
/// Ses her zaman just_audio'dan çalar; 3. sayfada klip sessiz
/// oynatılır ve sesin konumuna göre senkronlanır.
class PlayerScreen extends StatefulWidget {
  final Song song;
  const PlayerScreen({super.key, required this.song});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final _audio = AudioPlayer();
  late final VideoPlayerController _video;
  final _pages = PageController();
  int _page = 0;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _audio.setFilePath(widget.song.audioPath);

    _video = VideoPlayerController.file(File(widget.song.videoPath));
    await _video.initialize();
    await _video.setVolume(0); // ses just_audio'dan geliyor
    await _video.setLooping(false);
    if (mounted) setState(() => _videoReady = true);

    _audio.playerStateStream.listen((s) {
      if (!_videoReady) return;
      if (s.playing && _page == 2) {
        _video.play();
      } else {
        _video.pause();
      }
    });

    _audio.play();
  }

  Future<void> _onPageChanged(int i) async {
    setState(() => _page = i);
    if (i == 2 && _videoReady) {
      // Kliple sesi aynı konuma getir.
      await _video.seekTo(_audio.position);
      if (_audio.playing) await _video.play();
    } else if (_videoReady) {
      await _video.pause();
    }
  }

  @override
  void dispose() {
    _audio.dispose();
    if (_videoReady) _video.dispose();
    _pages.dispose();
    super.dispose();
  }

  Widget _image(String path) => AspectRatio(
        aspectRatio: 1,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.file(File(path), fit: BoxFit.cover),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = widget.song;
    return Scaffold(
      appBar: AppBar(title: Text(s.title, overflow: TextOverflow.ellipsis)),
      body: Column(
        children: [
          Expanded(
            child: PageView(
              controller: _pages,
              onPageChanged: _onPageChanged,
              children: [
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: _image(s.coverPath),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: _image(s.thumbPath),
                  ),
                ),
                Center(
                  child: _videoReady
                      ? AspectRatio(
                          aspectRatio: _video.value.aspectRatio,
                          child: VideoPlayer(_video),
                        )
                      : const CircularProgressIndicator(),
                ),
              ],
            ),
          ),
          _Dots(count: 3, index: _page),
          const SizedBox(height: 12),
          Text(s.title, style: Theme.of(context).textTheme.titleLarge),
          Text(s.artist),
          _Controls(audio: _audio),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _Dots extends StatelessWidget {
  final int count, index;
  const _Dots({required this.count, required this.index});

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(
          count,
          (i) => AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.all(4),
            width: i == index ? 20 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: i == index
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      );
}

class _Controls extends StatelessWidget {
  final AudioPlayer audio;
  const _Controls({required this.audio});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        StreamBuilder<Duration>(
          stream: audio.positionStream,
          builder: (_, snap) {
            final pos = snap.data ?? Duration.zero;
            final total = audio.duration ?? Duration.zero;
            return Slider(
              value: pos.inMilliseconds
                  .clamp(0, total.inMilliseconds > 0 ? total.inMilliseconds : 1)
                  .toDouble(),
              max: total.inMilliseconds > 0
                  ? total.inMilliseconds.toDouble()
                  : 1,
              onChanged: (v) => audio.seek(Duration(milliseconds: v.toInt())),
            );
          },
        ),
        StreamBuilder<PlayerState>(
          stream: audio.playerStateStream,
          builder: (_, snap) {
            final playing = snap.data?.playing ?? false;
            return IconButton(
              iconSize: 56,
              icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
              onPressed: playing ? audio.pause : audio.play,
            );
          },
        ),
      ],
    );
  }
}
