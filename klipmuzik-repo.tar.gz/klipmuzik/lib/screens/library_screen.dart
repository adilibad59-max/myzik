import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';

import '../data/song_db.dart';
import '../models/song.dart';
import '../services/download_service.dart';
import 'player_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<Song> _songs = [];
  String? _status;
  StreamSubscription? _shareSub;

  @override
  void initState() {
    super.initState();
    _load();

    // YouTube'dan "Paylaş > Klipmüzik" ile gelen linkler.
    _shareSub = ReceiveSharingIntent.instance.getMediaStream().listen((files) {
      for (final f in files) {
        if (f.path.startsWith('http')) _download(f.path);
      }
    });
    ReceiveSharingIntent.instance.getInitialMedia().then((files) {
      for (final f in files) {
        if (f.path.startsWith('http')) _download(f.path);
      }
      ReceiveSharingIntent.instance.reset();
    });
  }

  @override
  void dispose() {
    _shareSub?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final songs = await SongDb.instance.all();
    if (mounted) setState(() => _songs = songs);
  }

  Future<void> _download(String url) async {
    try {
      await DownloadService.download(
        url.trim(),
        onStatus: (s) => setState(() => _status = s),
      );
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('İndirilemedi: $e')));
      }
    } finally {
      if (mounted) setState(() => _status = null);
    }
  }

  Future<void> _askUrl() async {
    final ctrl = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('YouTube linki'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'https://youtu.be/...'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctrl.text),
            child: const Text('İndir'),
          ),
        ],
      ),
    );
    if (url != null && url.trim().isNotEmpty) _download(url);
  }

  Future<void> _remove(Song s) async {
    await SongDb.instance.delete(s.id);
    final dir = File(s.audioPath).parent;
    if (dir.existsSync()) dir.deleteSync(recursive: true);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Klipmüzik'),
        actions: [
          IconButton(
            tooltip: 'yt-dlp güncelle',
            icon: const Icon(Icons.system_update),
            onPressed: () async {
              final v = await DownloadService.updateEngine();
              if (!mounted) return;
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('yt-dlp: $v')));
            },
          ),
        ],
        bottom: _status == null
            ? null
            : PreferredSize(
                preferredSize: const Size.fromHeight(36),
                child: Column(
                  children: [
                    const LinearProgressIndicator(),
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(_status!),
                    ),
                  ],
                ),
              ),
      ),
      body: _songs.isEmpty
          ? const Center(child: Text('Henüz şarkı yok. + ile link ekle.'))
          : ListView.builder(
              itemCount: _songs.length,
              itemBuilder: (_, i) {
                final s = _songs[i];
                return Dismissible(
                  key: ValueKey(s.id),
                  background: Container(color: Colors.red),
                  onDismissed: (_) => _remove(s),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(s.coverPath),
                        width: 52,
                        height: 52,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(s.title, maxLines: 1),
                    subtitle: Text(s.artist, maxLines: 1),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PlayerScreen(song: s),
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _askUrl,
        child: const Icon(Icons.add),
      ),
    );
  }
}
