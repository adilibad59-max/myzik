import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../data/song_db.dart';
import '../models/song.dart';

/// Android tarafındaki yt-dlp köprüsünü çağırır (MainActivity.kt).
class DownloadService {
  static const _channel = MethodChannel('klipmuzik/ytdlp');

  /// [url] için ses, klip ve kapakları indirir, veritabanına ekler.
  /// [onStatus] ilerleme mesajlarını arayüze iletir.
  static Future<Song> download(
    String url, {
    void Function(String status)? onStatus,
  }) async {
    final base = await getApplicationDocumentsDirectory();

    onStatus?.call('Bilgiler alınıyor...');
    final info = Map<String, dynamic>.from(
      await _channel.invokeMethod('info', {'url': url}),
    );
    final id = info['id'] as String;
    final dir = Directory(p.join(base.path, 'songs', id))
      ..createSync(recursive: true);

    onStatus?.call('Ses indiriliyor...');
    final audio = await _channel.invokeMethod<String>('audio', {
      'url': url,
      'dir': dir.path,
    });

    onStatus?.call('Klip indiriliyor...');
    final video = await _channel.invokeMethod<String>('video', {
      'url': url,
      'dir': dir.path,
    });

    onStatus?.call('Kapaklar indiriliyor...');
    final thumb = await _channel.invokeMethod<String>('thumbnail', {
      'url': url,
      'dir': dir.path,
    });

    // Albüm kapağı ayrı bulunamazsa video thumbnail'i kullanılır.
    // (İleride MusicBrainz / iTunes Search API ile gerçek albüm kapağı eklenebilir.)
    final cover = thumb!;

    final song = Song(
      id: id,
      title: (info['track'] ?? info['title']) as String,
      artist: (info['artist'] ?? info['uploader'] ?? 'Bilinmeyen') as String,
      coverPath: cover,
      thumbPath: thumb,
      audioPath: audio!,
      videoPath: video!,
    );
    await SongDb.instance.insert(song);
    onStatus?.call('Tamam');
    return song;
  }

  /// Uygulamadaki yt-dlp sürümünü günceller (YouTube sık değiştiği için).
  static Future<String?> updateEngine() =>
      _channel.invokeMethod<String>('update');
}
