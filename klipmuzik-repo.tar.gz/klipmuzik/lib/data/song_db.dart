import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/song.dart';

class SongDb {
  SongDb._();
  static final SongDb instance = SongDb._();

  Database? _db;

  Future<Database> get _database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dir, 'klipmuzik.db'),
      version: 1,
      onCreate: (db, _) => db.execute('''
        CREATE TABLE songs(
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          artist TEXT NOT NULL,
          coverPath TEXT NOT NULL,
          thumbPath TEXT NOT NULL,
          audioPath TEXT NOT NULL,
          videoPath TEXT NOT NULL,
          addedAt INTEGER NOT NULL
        )
      '''),
    );
    return _db!;
  }

  Future<List<Song>> all() async {
    final db = await _database;
    final rows = await db.query('songs', orderBy: 'addedAt DESC');
    return rows.map(Song.fromMap).toList();
  }

  Future<void> insert(Song s) async {
    final db = await _database;
    await db.insert(
      'songs',
      {...s.toMap(), 'addedAt': DateTime.now().millisecondsSinceEpoch},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> delete(String id) async {
    final db = await _database;
    await db.delete('songs', where: 'id = ?', whereArgs: [id]);
  }
}
