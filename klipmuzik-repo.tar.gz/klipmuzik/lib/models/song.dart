class Song {
  final String id;
  final String title;
  final String artist;

  /// Şarkının kendi kapağı (albüm kapağı, yoksa video thumbnail'i).
  final String coverPath;

  /// Klibin kapağı (video thumbnail'i).
  final String thumbPath;

  /// Sadece ses dosyası (m4a).
  final String audioPath;

  /// Klip dosyası (mp4).
  final String videoPath;

  const Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.coverPath,
    required this.thumbPath,
    required this.audioPath,
    required this.videoPath,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'artist': artist,
        'coverPath': coverPath,
        'thumbPath': thumbPath,
        'audioPath': audioPath,
        'videoPath': videoPath,
      };

  factory Song.fromMap(Map<dynamic, dynamic> m) => Song(
        id: m['id'] as String,
        title: m['title'] as String,
        artist: m['artist'] as String,
        coverPath: m['coverPath'] as String,
        thumbPath: m['thumbPath'] as String,
        audioPath: m['audioPath'] as String,
        videoPath: m['videoPath'] as String,
      );
}
