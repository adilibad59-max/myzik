#!/usr/bin/env python3
"""flutter create sonrası Android projesini youtubedl-android için yamalar."""
import re
import shutil
from pathlib import Path

root = Path(__file__).resolve().parent.parent
android = root / "android"
app = android / "app"

YT = "io.github.junkfood02.youtubedl-android"
VER = "0.17.2"

# 1) MainActivity.kt
dst = app / "src/main/kotlin/com/example/klipmuzik/MainActivity.kt"
dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy(root / "android_snippets/MainActivity.kt", dst)

# 2) build.gradle(.kts)
kts = (app / "build.gradle.kts").exists()
gradle = app / ("build.gradle.kts" if kts else "build.gradle")
text = gradle.read_text()

text = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion",
              "minSdk = 24" if kts else "minSdkVersion 24", text)

if kts:
    ndk = '        ndk { abiFilters += listOf("arm64-v8a") }\n'
    pack = '    packaging { jniLibs { useLegacyPackaging = true } }\n'
    deps = (f'\ndependencies {{\n'
            f'    implementation("{YT}:library:{VER}")\n'
            f'    implementation("{YT}:ffmpeg:{VER}")\n}}\n')
else:
    ndk = '        ndk { abiFilters "arm64-v8a" }\n'
    pack = '    packagingOptions { jniLibs { useLegacyPackaging = true } }\n'
    deps = (f'\ndependencies {{\n'
            f'    implementation "{YT}:library:{VER}"\n'
            f'    implementation "{YT}:ffmpeg:{VER}"\n}}\n')

text = re.sub(r"(defaultConfig\s*\{\n)", r"\1" + ndk, text, count=1)
text = re.sub(r"(\nandroid\s*\{\n)", r"\1" + pack, text, count=1)
text += deps
gradle.write_text(text)

# 3) AndroidManifest.xml
mf = app / "src/main/AndroidManifest.xml"
m = mf.read_text()
if "android.permission.INTERNET" not in m:
    m = m.replace("<application",
                  '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
share = """
            <intent-filter>
                <action android:name="android.intent.action.SEND"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <data android:mimeType="text/plain"/>
            </intent-filter>
        </activity>"""
m = m.replace("</activity>", share, 1)
mf.write_text(m)

print("Android yamaları uygulandı:", gradle.name)
