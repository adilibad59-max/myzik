package com.example.klipmuzik

import android.os.Handler
import android.os.Looper
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        io.execute {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "klipmuzik/ytdlp")
            .setMethodCallHandler { call, result ->
                io.execute {
                    try {
                        val out = handle(call)
                        main.post { result.success(out) }
                    } catch (e: Exception) {
                        main.post { result.error("YTDLP", e.message, null) }
                    }
                }
            }
    }

    private fun handle(call: MethodCall): Any? {
        val url = call.argument<String>("url")
        val dir = call.argument<String>("dir")

        return when (call.method) {
            "info" -> {
                val i = YoutubeDL.getInstance().getInfo(url!!)
                mapOf(
                    "id" to i.id,
                    "title" to i.title,
                    "uploader" to i.uploader,
                    "artist" to null,
                    "track" to null
                )
            }
            "audio" -> {
                val req = YoutubeDLRequest(url!!).apply {
                    addOption("-x")
                    addOption("--audio-format", "m4a")
                    addOption("-o", "$dir/audio.%(ext)s")
                }
                YoutubeDL.getInstance().execute(req, null)
                "$dir/audio.m4a"
            }
            "video" -> {
                val req = YoutubeDLRequest(url!!).apply {
                    addOption("-f", "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b")
                    addOption("--merge-output-format", "mp4")
                    addOption("-o", "$dir/video.%(ext)s")
                }
                YoutubeDL.getInstance().execute(req, null)
                "$dir/video.mp4"
            }
            "thumbnail" -> {
                val req = YoutubeDLRequest(url!!).apply {
                    addOption("--skip-download")
                    addOption("--write-thumbnail")
                    addOption("--convert-thumbnails", "jpg")
                    addOption("-o", "$dir/thumb")
                }
                YoutubeDL.getInstance().execute(req, null)
                File("$dir/thumb.jpg").absolutePath
            }
            "update" -> {
                val status = YoutubeDL.getInstance()
                    .updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                status?.name
            }
            else -> throw IllegalArgumentException("Bilinmeyen metod: ${call.method}")
        }
    }
}
