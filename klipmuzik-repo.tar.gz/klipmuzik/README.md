# Klipmüzik

YouTube'dan ses + klip + kapak indiren, üçü arasında kaydırarak geçilen kişisel müzik uygulaması (Flutter, Android).

## Ekranlar
1. **Şarkı kapağı**
2. **Klip kapağı**
3. **Klip** (ses kesintisiz devam eder, klip aynı konuma senkronlanır)

## Kurulum

```bash
flutter create --org com.example --project-name klipmuzik --platforms android .
flutter pub get
```

`flutter create` mevcut `pubspec.yaml` ve `lib/` dosyalarına dokunmaz. Sonra:

### 1) Android tarafı
- `android_snippets/MainActivity.kt` dosyasını
  `android/app/src/main/kotlin/com/example/klipmuzik/MainActivity.kt` üzerine kopyala.
- `android/app/build.gradle(.kts)` içine:

```gradle
android {
    defaultConfig {
        minSdk = 24
        ndk { abiFilters += listOf("arm64-v8a") }   // S25 FE için yeterli
    }
    packagingOptions {
        jniLibs { useLegacyPackaging = true }       // youtubedl-android için şart
    }
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
```

> Sürüm numarasını https://github.com/yausername/youtubedl-android (veya JunkFood02 fork'u)
> sayfasından kontrol et, yenisi çıkmış olabilir.

### 2) AndroidManifest.xml
`<manifest>` içine:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```
`MainActivity` `<activity>` etiketine (paylaş menüsünden link almak için):
```xml
<intent-filter>
    <action android:name="android.intent.action.SEND"/>
    <category android:name="android.intent.category.DEFAULT"/>
    <data android:mimeType="text/plain"/>
</intent-filter>
```

### 3) Çalıştır
```bash
flutter run
```

## Kullanım
- Sağ alttaki **+** ile link yapıştır, ya da YouTube'da **Paylaş → Klipmüzik**.
- İndirme çalışmazsa sağ üstteki **güncelle** ikonuna bas (yt-dlp motoru güncellenir).
- Şarkıyı sola/sağa kaydırarak sil.

## Dosya yapısı
```
lib/
  main.dart
  models/song.dart
  data/song_db.dart            SQLite kütüphane
  services/download_service.dart  Flutter ↔ yt-dlp köprüsü
  screens/library_screen.dart  liste + indirme
  screens/player_screen.dart   3 sayfalı oynatıcı
android_snippets/MainActivity.kt
```

## Sonraki adımlar
- Gerçek albüm kapağı (iTunes Search API / MusicBrainz) → `coverPath`
- Arka planda çalma ve bildirim kontrolleri (`just_audio_background`)
- Oynatma listesi, karıştırma, favoriler
- Sanatçı/şarkı adı için `info` çağrısında `artist`/`track` alanlarını doldurma

## Not
YouTube'un kullanım şartları indirmeye izin vermez; uygulama yalnızca kişisel kullanım içindir, dağıtılmamalıdır.
